function x2(n,i,x1,r) {return x1 + r*Math.sin(2*Math.PI*n/i);};
function y2(n,i,y1,r) {return y1 - r*Math.cos(2*Math.PI*n/i);};

var nombreMeses = ["ENE", "FEB", "MAR", "ABR", "MAY", "JUN",
"JUL", "AGO", "SEP", "OCT", "NOV", "DEC"];

var nombreDias = ["DOM", "LUN", "MAR", "MIE", "JUE", "VIE", "SAB"];

$( document ).ready(function(){
        $("#vector").svg({onLoad: function(svg){
            var svg = $('#vector').svg('get'); 
            var seg = $($('#seg').val(), svg.root());
            var min = $($('#min').val(), svg.root());
            var hor = $($('#hor').val(), svg.root());
            var dec = $($('#dec').val(), svg.root());
            var tex = $($('#tex').val(), svg.root());
            var texFec = $($('#fechaDia').val(), svg.root());

            function mostrar_fecha() {
                var d = new Date();

                var diaSemana = nombreDias[d.getDay()];
                var dia = d.getDate();
                var mes = nombreMeses[d.getMonth()];
                var ano = d.getFullYear().toString().substr(2);

                dia = dia < 10 ? "0"+dia : dia;

                texFec.html(diaSemana + " " + dia + " " + mes + " " + ano);
            }

            function mostrar_hora( ) {
                var d = new Date();

                var h = d.getHours();
                var m = d.getMinutes();
                var s = d.getSeconds();
                var c = d.getMilliseconds()/100;

                h = h < 10 ? "0"+h : h;
                m = m < 10 ? "0"+m : m;
                s = s < 10 ? "0"+s : s;

                tex.html(h + ":" + m + ":" + s);
                seg.attr('x2', x2(s,60,100,48)).attr('y2', y2(s,60,70,48));
                min.attr('x2', x2(m,60,100,40)).attr('y2', y2(m,60,70,40));
                hor.attr('x2', x2(h,12,100,30)).attr('y2', y2(h,12,70,30));
                dec.attr('x2', x2(c,10,100,7 )).attr('y2', y2(c,10,100,7));
            }

            setInterval(function(){mostrar_hora();}, 10);
            setInterval(function(){mostrar_fecha();}, 1000);

            mostrar_hora();
            mostrar_fecha();
        }
        });
});
